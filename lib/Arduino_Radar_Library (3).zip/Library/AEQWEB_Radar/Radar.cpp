/*
  Radar Basic Library 
  More information at: https://www.aeq-web.com/arduino-radar-motion-detector/
  Created by Alex E., September 17, 2017.
*/

#include "Radar.h"

Radar::Radar(int pin)
{
  _pin = pin;
}

void Radar::settolerance(int tol){
  _tol = tol;
}

void Radar::measure()
{
  int per = (1024/100)*_tol;
  int sval = analogRead(_pin);
  if(sval > 512+per || sval < 512-per){
  _rtv = 1;
  }else{
  _rtv = 0;
  }
}

int Radar::rtv(){
  return _rtv;
}

